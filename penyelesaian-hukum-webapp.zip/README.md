# Asisten Hukum AI - Web App

## Jalankan Backend
```bash
cd backend
npm install express body-parser cors
node index.js
```

## Jalankan Frontend (React)
```bash
cd frontend
npm create vite@latest
# pilih 'react', lalu pindahkan /src dan /public ke folder tersebut
npm install
npm run dev
```

Akses di http://localhost:5173
