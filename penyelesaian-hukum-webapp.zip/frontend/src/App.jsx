import React, { useState } from 'react';

function App() {
  const [pertanyaan, setPertanyaan] = useState('');
  const [jawaban, setJawaban] = useState('');

  const kirim = async () => {
    const res = await fetch('http://localhost:3000/api/ai-jawab', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pertanyaan }),
    });
    const data = await res.json();
    setJawaban(data.jawaban);
  };

  return (
    <div className="p-6 max-w-xl mx-auto text-center">
      <h1 className="text-3xl font-bold mb-4 text-blue-700">🧠 Penyelesaian Hukum</h1>
      <textarea className="border w-full p-2 rounded" rows="4"
        placeholder="Tulis permasalahan hukum Anda..."
        value={pertanyaan} onChange={e => setPertanyaan(e.target.value)} />
      <button className="mt-2 px-4 py-2 bg-blue-600 text-white rounded" onClick={kirim}>
        Konsultasi Sekarang
      </button>
      <div className="mt-4 text-left whitespace-pre-wrap bg-gray-100 p-3 rounded border">
        {jawaban}
      </div>
    </div>
  );
}

export default App;
