const express = require('express');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');

app.use(cors());
app.use(bodyParser.json());

let hukumDatabase = [];
try {
  const data = fs.readFileSync('./hukum_nasional.json', 'utf-8');
  hukumDatabase = JSON.parse(data);
} catch (error) {
  console.error('Gagal memuat hukum_nasional.json:', error);
}

function klasifikasiTopik(pertanyaan) {
  const keyword = pertanyaan.toLowerCase();
  const cocok = hukumDatabase.find(p =>
    p.topik?.some(k => keyword.includes(k.toLowerCase())) ||
    p.versi_sederhana?.toLowerCase().includes(keyword) ||
    p.isi?.toLowerCase().includes(keyword)
  );
  if (!cocok) return { topik: "Tidak Dikenali", pasal: null };
  return { topik: cocok.kategori || "Umum", pasal: cocok };
}

function generateJawaban(pertanyaan) {
  const hasil = klasifikasiTopik(pertanyaan);
  if (!hasil.pasal) {
    return "Maaf, belum ditemukan dasar hukum yang sesuai.";
  }
  return `📜 Pasal ${hasil.pasal.pasal} (${hasil.pasal.jenis})\n\n${hasil.pasal.isi}\n\n💡 ${hasil.pasal.versi_sederhana}\n📌 ${hasil.pasal.saran || 'Konsultasikan lebih lanjut dengan ahli hukum.'}`;
}

app.post('/api/ai-jawab', (req, res) => {
  const { pertanyaan } = req.body;
  const jawaban = generateJawaban(pertanyaan);
  res.json({ jawaban });
});

app.listen(port, () => {
  console.log(`Server hukum AI aktif di http://localhost:${port}`);
});
